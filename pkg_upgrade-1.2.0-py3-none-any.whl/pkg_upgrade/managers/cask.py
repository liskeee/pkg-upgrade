import shutil

from pkg_upgrade._brew_cache import get_brew_outdated
from pkg_upgrade._subprocess import run_command
from pkg_upgrade.manager import PackageManager
from pkg_upgrade.models import Package, Result
from pkg_upgrade.registry import register_manager


@register_manager
class CaskManager(PackageManager):
    name = "Homebrew Casks"
    key = "cask"
    icon = "🍻"
    platforms = frozenset({"macos"})
    depends_on = ("brew",)

    async def is_available(self) -> bool:
        return shutil.which("brew") is not None

    async def check_outdated(self) -> list[Package]:
        data = await get_brew_outdated()
        packages = []
        for c in data.get("casks", []):
            installed = c.get("installed_versions") or []
            current = installed[0] if isinstance(installed, list) and installed else "unknown"
            packages.append(
                Package(
                    name=c["name"],
                    current_version=current,
                    latest_version=c["current_version"],
                )
            )
        return packages

    async def upgrade(self, package: Package) -> Result:
        code, stdout, stderr = await run_command(["brew", "upgrade", "--cask", package.name])
        if code == 0:
            return Result(success=True, message=stdout.strip(), package=package)
        return Result(success=False, message=stderr.strip(), package=package)
